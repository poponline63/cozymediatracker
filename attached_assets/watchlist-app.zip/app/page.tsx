"use client"

import WatchlistApp from "../watchlist-app"

export default function SyntheticV0PageForDeployment() {
  return <WatchlistApp />
}