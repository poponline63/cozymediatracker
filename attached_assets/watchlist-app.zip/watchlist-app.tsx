import { Bell, Menu, Plus, Search, Users } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function WatchlistApp() {
  return (
    <div className="flex flex-col min-h-screen bg-[#2f3e46]">
      <header className="sticky top-0 z-50 w-full border-b border-[#84a98c] bg-[#354f52] shadow-sm">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center space-x-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Toggle navigation menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 bg-[#354f52]">
                <nav className="flex flex-col space-y-4 mt-8">
                  <Link href="#" className="text-[#cad2c5] hover:text-[#e0e5df] text-lg font-medium transition-colors">
                    Watchlist
                  </Link>
                  <Link href="#" className="text-[#cad2c5] hover:text-[#e0e5df] text-lg font-medium transition-colors">
                    Friends
                  </Link>
                  <Link href="#" className="text-[#cad2c5] hover:text-[#e0e5df] text-lg font-medium transition-colors">
                    Discover
                  </Link>
                  <Link href="#" className="text-[#cad2c5] hover:text-[#e0e5df] text-lg font-medium transition-colors">
                    Settings
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-[#cad2c5]">🍃 Cozy Watch</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="#" className="text-[#cad2c5] hover:text-[#e0e5df] text-lg font-medium transition-colors">
              Watchlist
            </Link>
            <Link href="#" className="text-[#cad2c5] hover:text-[#e0e5df] text-lg font-medium transition-colors">
              Friends
            </Link>
            <Link href="#" className="text-[#cad2c5] hover:text-[#e0e5df] text-lg font-medium transition-colors mr-6">
              Discover
            </Link>
          </nav>
          <div className="w-6" />
          <div className="flex items-center space-x-4">
            <form className="hidden md:block">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-[#cad2c5]" />
                <Input
                  type="search"
                  placeholder="Search..."
                  className="pl-8 bg-[#52796f] border-[#84a98c] text-[#cad2c5] placeholder-[#84a98c] focus:ring-[#84a98c] focus:border-[#84a98c]"
                />
              </div>
            </form>
            <Button variant="ghost" size="icon" className="text-[#cad2c5] hover:text-[#e0e5df] hover:bg-[#52796f]">
              <Bell className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Button>
            <Button variant="ghost" size="icon" className="text-[#cad2c5] hover:text-[#e0e5df] hover:bg-[#52796f]">
              <Users className="h-5 w-5" />
              <span className="sr-only">Friends</span>
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 py-12 px-4 md:px-6">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-[#cad2c5] mb-8">Watchlist</h1>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <div
                key={item}
                className="bg-[#52796f] border border-[#84a98c] rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
              >
                <div className="aspect-video bg-[#354f52]" />
                <div className="p-4">
                  <h3 className="text-xl font-semibold text-[#cad2c5] mb-2">Show Title</h3>
                  <p className="text-[#84a98c] mb-4">Type • Genre • Year</p>
                  <div className="flex justify-between items-center">
                    <Button
                      variant="outline"
                      className="text-[#e0e5df] border-[#84a98c] bg-[#354f52] hover:bg-[#52796f] hover:text-white font-semibold"
                    >
                      Watch Now
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-[#cad2c5] hover:text-[#e0e5df] hover:bg-[#354f52]"
                    >
                      <Plus className="h-5 w-5" />
                      <span className="sr-only">Add to list</span>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
      <footer className="w-full border-t border-[#84a98c] bg-[#354f52] py-6">
        <div className="container flex justify-between items-center px-4 md:px-6">
          <p className="text-[#cad2c5]">© 2025 Cozy Watch. All rights reserved.</p>
          <nav className="flex space-x-4">
            <Link href="#" className="text-[#cad2c5] hover:text-[#e0e5df]">
              Terms
            </Link>
            <Link href="#" className="text-[#cad2c5] hover:text-[#e0e5df]">
              Privacy
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

